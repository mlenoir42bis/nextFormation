package com.apps.entity.model;

public enum StatutCommande {
	ATTENTE_PREPARATION,
	PREPARE,
	LIVRE;
}
