package com.apps.entity.model;

public enum StatutIngredient {
	DISPONIBLE,
	BIENTOT_DISPONIBLE,
	INDISPONIBLE;
}
