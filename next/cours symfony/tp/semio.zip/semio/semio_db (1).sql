-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Ven 18 Avril 2014 à 17:12
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `semio_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `salle`
--

CREATE TABLE IF NOT EXISTS `salle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Contenu de la table `salle`
--

INSERT INTO `salle` (`id`, `name`) VALUES
(1, 'Pablo Picasso'),
(2, 'Paul Klee'),
(3, 'Edward Hopper'),
(4, 'Vincent Van Gogh');

-- --------------------------------------------------------

--
-- Structure de la table `seminaire`
--

CREATE TABLE IF NOT EXISTS `seminaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salle_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `short_resume` longtext COLLATE utf8_unicode_ci NOT NULL,
  `long_resume` longtext COLLATE utf8_unicode_ci NOT NULL,
  `date_seminaire` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `intervenant_id` int(11) DEFAULT NULL,
  `is_online` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_32089333DC304035` (`salle_id`),
  KEY `IDX_32089333AB9A1716` (`intervenant_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Contenu de la table `seminaire`
--

INSERT INTO `seminaire` (`id`, `salle_id`, `title`, `short_resume`, `long_resume`, `date_seminaire`, `updated_at`, `intervenant_id`, `is_online`) VALUES
(1, 3, 'Vous reprendrez bien un peu de Python ? Non ?', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut .', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', '2013-04-25 06:00:00', '2013-03-17 14:00:00', 1, 1),
(2, 1, 'sss', 'sss', 'sss', '2013-03-28 00:00:00', '0000-00-00 00:00:00', 1, 1),
(4, 1, 'dd', 'dd', 'ddd', '2008-01-19 17:00:00', '2013-03-21 22:00:15', 1, 0),
(5, 1, 'dddddd', 'dddd', 'ddd', '2008-01-19 17:00:00', '2013-03-21 22:01:51', 1, 1),
(6, 2, 'cxvxc', 'vcxv', 'vxcvx', '2008-02-17 00:00:00', '2013-03-22 09:44:54', 1, 1),
(7, 2, 'test titre', 'prochain semi resume', 'prochain semi long', '2013-11-27 10:00:00', '2013-11-22 16:02:36', 3, 0),
(8, 2, 'python', 'dldjlds', 'dd', '2015-02-18 15:00:00', '2014-04-17 14:30:37', 2, 1);

-- --------------------------------------------------------

--
-- Structure de la table `seminaire_theme`
--

CREATE TABLE IF NOT EXISTS `seminaire_theme` (
  `seminaire_id` int(11) NOT NULL,
  `theme_id` int(11) NOT NULL,
  PRIMARY KEY (`seminaire_id`,`theme_id`),
  KEY `IDX_639B04D8CEA14D8` (`seminaire_id`),
  KEY `IDX_639B04D859027487` (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `seminaire_theme`
--

INSERT INTO `seminaire_theme` (`seminaire_id`, `theme_id`) VALUES
(1, 3),
(2, 1),
(2, 2),
(4, 3),
(5, 3),
(6, 2),
(6, 3),
(7, 3),
(8, 1),
(8, 4);

-- --------------------------------------------------------

--
-- Structure de la table `theme`
--

CREATE TABLE IF NOT EXISTS `theme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Contenu de la table `theme`
--

INSERT INTO `theme` (`id`, `name`) VALUES
(1, 'Mathématiques'),
(2, 'Philosophie'),
(3, 'Histoire'),
(4, 'Politique'),
(5, 'Santé'),
(6, 'Informatique');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `locked` tinyint(1) NOT NULL,
  `expired` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `credentials_expired` tinyint(1) NOT NULL,
  `credentials_expire_at` datetime DEFAULT NULL,
  `biographie` longtext COLLATE utf8_unicode_ci,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_2DA1797792FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_2DA17977A0D96FBF` (`email_canonical`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `username`, `username_canonical`, `email`, `email_canonical`, `enabled`, `salt`, `password`, `last_login`, `locked`, `expired`, `expires_at`, `confirmation_token`, `password_requested_at`, `roles`, `credentials_expired`, `credentials_expire_at`, `biographie`, `url`, `firstname`, `lastname`) VALUES
(1, 'alain', 'alain', 'alain.p@gmail.com', 'alain.p@gmail.com', 1, 'gvzjkp67py0cg0sc84os4w0cc48k0wo', '3aBl7m9XCdeOq4JEDnYy2/RBII/eIqq6tkPDUv7Neo/qUkcSvnwns4nnChElcoPjPtqOIaZzsY+K82JQG+HAeg==', '2013-03-21 21:59:49', 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL, 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna', NULL, 'Alain', 'Perrouac'),
(2, 'marie', 'marie', 'm.de.ubeda@gmail.com', 'm.de.ubeda@gmail.com', 1, '1srxwi01f6f4w8c008o4ks0wckc48c4', 'lqp3Je2SeNh3Gi7FY7HvWZchNyPWvaQKDW11sknelYdNF+VSpv8laP62E8GE5iIlqnCXPDYhvbERTN2rkvmmLg==', '2014-04-17 15:05:32', 0, 0, NULL, NULL, NULL, 'a:1:{i:0;s:16:"ROLE_SUPER_ADMIN";}', 0, NULL, 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna', NULL, 'Marie', 'Allgouët'),
(3, 'titi', 'titi', 'titi@gmail.com', 'titi@gmail.com', 1, '1jgqxdx40g68k8ggc8s4o0kkwoggwsw', 'CBPVfrgIDI2UIf2fQPGRdclCvn9ny1agDo/VKSLwXaDMiAljVl+lwgCp2BfPZfR6uFyLOjjdfH2B4Y3hBQa5xg==', NULL, 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL, NULL, NULL, NULL, NULL);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `seminaire`
--
ALTER TABLE `seminaire`
  ADD CONSTRAINT `FK_32089333AB9A1716` FOREIGN KEY (`intervenant_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_32089333DC304035` FOREIGN KEY (`salle_id`) REFERENCES `salle` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `seminaire_theme`
--
ALTER TABLE `seminaire_theme`
  ADD CONSTRAINT `FK_639B04D859027487` FOREIGN KEY (`theme_id`) REFERENCES `theme` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_639B04D8CEA14D8` FOREIGN KEY (`seminaire_id`) REFERENCES `seminaire` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
