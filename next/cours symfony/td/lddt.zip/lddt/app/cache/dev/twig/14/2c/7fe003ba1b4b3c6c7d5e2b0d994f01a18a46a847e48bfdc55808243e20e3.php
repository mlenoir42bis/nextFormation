<?php

/* LddtMainBundle:Main:edit.html.twig */
class __TwigTemplate_142c7fe003ba1b4b3c6c7d5e2b0d994f01a18a46a847e48bfdc55808243e20e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("LddtMainBundle::main_n2.html.twig");

        $this->blocks = array(
            'n3' => array($this, 'block_n3'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "LddtMainBundle::main_n2.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_n3($context, array $blocks = array())
    {
        // line 4
        echo "     <!-- Template Niveau 3 -->
<div class=\"row\">
    <div class=\"well well-lg\" style=\"height:450px\">
            <div class=\"col-lg-3 col-lg-offset-1\">
                <h1>Modifiez le dessin ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "title", array()), "html", null, true);
        echo " </h1>
<img width=\"290\" src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl($this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "getWebPath", array())), "html", null, true);
        echo "\" />
            </div>
            <div class=\"col-lg-5 col-lg-offset-1\">
                <h3>Envoyez votre dessin !</h3>
                <!-- Template Formulaire -->
 ";
        // line 14
        $this->env->loadTemplate("LddtMainBundle:Main:form.html.twig")->display($context);
        echo "          
                
                <!-- Fin Template Formulaire -->
                <!-- Si le visiteur n'est pas identifié -->
                       <!-- <p>Merci de vous<a href=\"#\"> indentifier</a>  pour poster vos dessins !</p> -->
            </div>
    </div>
</div><!-- Fin Template Niveau 3 -->
";
    }

    public function getTemplateName()
    {
        return "LddtMainBundle:Main:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 14,  41 => 9,  37 => 8,  31 => 4,  28 => 3,);
    }
}
