<?php

// ::main_n1.html.twig
return array (
  'b96b79a' => 
  array (
    0 => 
    array (
      0 => '@LddtAssetsBundle/Resources/public/css/bootstrap.css',
      1 => '@LddtAssetsBundle/Resources/public/css/lddt.css',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
      1 => 'yui_css',
    ),
    2 => 
    array (
      'output' => '_controller/css/b96b79a.css',
      'name' => 'b96b79a',
      'debug' => false,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
