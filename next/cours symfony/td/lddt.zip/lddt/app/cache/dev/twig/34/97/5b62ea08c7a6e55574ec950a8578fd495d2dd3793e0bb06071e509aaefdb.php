<?php

/* ::main_n1.html.twig */
class __TwigTemplate_34975b62ea08c7a6e55574ec950a8578fd495d2dd3793e0bb06071e509aaefdb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- NIVEAU1 -->
<!DOCTYPE html>
<html lang=\"fr\">
  <head>
    <meta charset=\"utf-8\">
    <!-- Titre Princiapl + Titre \"hérité\" -->
    <title>Les dessins du téléphone</title>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"description\" content=\"Envoyez vos dessins réalisés au téléphone.\">
    <meta name=\"author\" content=\"Marie de Ubeda\">
    <!-- Bootstrap -->
";
        // line 13
        echo " ";
        // asset "b96b79a"
        $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_b96b79a") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/b96b79a.css");
        // line 17
        echo " <link href=\"";
        echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
        echo "\" rel=\"stylesheet\">
 ";
        unset($context["asset_url"]);
        // line 19
        echo " 
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
      <script src=\"https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js\"></script>
    <![endif]-->

  </head>

  <body>

  ";
        // line 31
        $this->env->loadTemplate("LddtMainBundle:Main:menu.html.twig")->display($context);
        // line 32
        echo "    ";
        // line 33
        echo "    ";
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "    ";
        echo "   

             <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- Insertion Fichiers JS -->
        <script src=\"https://code.jquery.com/jquery.js\"></script>
        <script type=\"text/javascript\" src=\"js/bootstrap.js\"></script>
    <!-- Fin insertion JS -->
 
  </body>
</html><!-- Fin du NIVEAU 1 -->";
    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::main_n1.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 33,  64 => 34,  61 => 33,  59 => 32,  57 => 31,  43 => 19,  37 => 17,  33 => 13,  20 => 1,);
    }
}
