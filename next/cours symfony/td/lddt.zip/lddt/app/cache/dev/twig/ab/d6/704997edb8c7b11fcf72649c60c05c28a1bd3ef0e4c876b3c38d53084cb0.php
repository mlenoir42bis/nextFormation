<?php

/* LddtMainBundle:Main:show.html.twig */
class __TwigTemplate_abd6704997edb8c7b11fcf72649c60c05c28a1bd3ef0e4c876b3c38d53084cb0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("LddtMainBundle::main_n2.html.twig");

        $this->blocks = array(
            'n3' => array($this, 'block_n3'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "LddtMainBundle::main_n2.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_n3($context, array $blocks = array())
    {
        // line 4
        echo "<!-- Template Niveau 3 -->
<div class=\"row\">

    <div class=\"col-lg-7\">
        <h2>";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "title", array()), "html", null, true);
        echo "</h2>
        <img class=\"col-lg-12 well well-lg img-polaroid\" src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl($this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "getWebPath", array())), "html", null, true);
        echo "\" />
    </div>
    <div class=\"col-lg-5\">
        <div class=\"well SidebarShow\">
            <div class=\"col-lg-4\">

                <img src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl($this->getAttribute($this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "user", array()), "getWebPath", array())), "html", null, true);
        echo "\" class=\"col-lg-12 img-circle shadow\" /> <br/>

                <p class=\"AuthorName\"><a href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("lddt_main_user", array("id" => $this->getAttribute($this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "user", array()), "id", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "user", array()), "username", array()), "html", null, true);
        echo "</a></p>
            </div>
            <div class=\"col-lg-8\">
                <p> Voir plus de dessins dans: <a 
 href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("lddt_main_category", array("id" => $this->getAttribute($this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "category", array()), "id", array()))), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "category", array()), "name", array()), "html", null, true);
        echo "</a></p>

  ";
        // line 23
        if (($this->getAttribute($this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "colors", array()), "count", array()) > 0)) {
            echo "            
    <p style=\"margin-top:15px\"><strong>Couleurs:</strong></p>

    ";
            // line 26
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "colors", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["color"]) {
                // line 27
                echo "      <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("lddt_main_color", array("id" => $this->getAttribute($context["color"], "id", array()))), "html", null, true);
                echo "\"> <div class=\"colorBlock\" style=\"background:";
                echo twig_escape_filter($this->env, $this->getAttribute($context["color"], "code", array()), "html", null, true);
                echo "\">
                      </div></a>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['color'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 29
            echo "  
  ";
        }
        // line 31
        echo "  
  ";
        // line 32
        if ((((isset($context["proprio"]) ? $context["proprio"] : $this->getContext($context, "proprio")) == true) || $this->env->getExtension('security')->isGranted("ROLE_ADMIN"))) {
            // line 33
            echo "               
                <p class=\"ToolsButton\">
                    <a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("lddt_main_edit", array("id" => $this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-warning\">éditer</a>
                    <a href=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("lddt_main_delete", array("id" => $this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-danger\">supprimer</a>
                </p>
                
   ";
        }
        // line 39
        echo "             
            </div>
        </div>
    </div>

    <div class=\"col-lg-5\">
        <div class=\"well\">
            <div class=\"col-lg-12\">
                ";
        // line 47
        if ($this->env->getExtension('security')->isGranted("ROLE_USER")) {
            echo "  
  <!-- Template Formulaire -->
    ";
            // line 49
            $this->env->loadTemplate("LddtMainBundle:Main:form.html.twig")->display($context);
            echo "   
  <!-- Fin Template Formulaire -->
 ";
        } else {
            // line 52
            echo "  <!-- Si le visiteur n'est pas identifié -->
    <p>Merci de vous <a href=\"";
            // line 53
            echo $this->env->getExtension('routing')->getPath("fos_user_security_login");
            echo "\"> identifier</a> pour laisser un commentaire !</p>
 ";
        }
        // line 54
        echo "  
           

            </div>
            <h4>Commentaires</h4>
            <ul>
                ";
        // line 60
        if (($this->getAttribute($this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "comments", array()), "count", array()) == 0)) {
            // line 61
            echo "                       <!-- si pas de commentaire -->
                <p>Le dessin <strong><em>";
            // line 62
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "title", array()), "html", null, true);
            echo "</em></strong> n' a pas encore été commenté.</p>
                ";
        } else {
            // line 64
            echo "    ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable(twig_reverse_filter($this->env, $this->getAttribute((isset($context["draw"]) ? $context["draw"] : $this->getContext($context, "draw")), "comments", array())));
            foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
                // line 65
                echo "         <li>";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "user", array()), "username", array()), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["comment"], "createdAt", array()), "d/m/Y H:i"), "html", null, true);
                echo "</li>
         <li>";
                // line 66
                echo twig_escape_filter($this->env, $this->getAttribute($context["comment"], "content", array()), "html", null, true);
                echo "</li>
                    <hr />
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 69
            echo "                ";
        }
        // line 70
        echo "             

            </ul>
        </div>
    </div>
</div><!-- Fin Template Niveau 3 -->
";
    }

    public function getTemplateName()
    {
        return "LddtMainBundle:Main:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  188 => 70,  185 => 69,  176 => 66,  169 => 65,  164 => 64,  159 => 62,  156 => 61,  154 => 60,  146 => 54,  141 => 53,  138 => 52,  132 => 49,  127 => 47,  117 => 39,  110 => 36,  106 => 35,  102 => 33,  100 => 32,  97 => 31,  93 => 29,  81 => 27,  77 => 26,  71 => 23,  64 => 21,  55 => 17,  50 => 15,  41 => 9,  37 => 8,  31 => 4,  28 => 3,);
    }
}
