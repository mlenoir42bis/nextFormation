<?php

/* LddtMainBundle:Main:menu.html.twig */
class __TwigTemplate_3455479b156ad4a11b5f91bbd3b35e38f8555a3b1bd62414e44dfbeac8db3d17 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- Template menu principal -->
<div class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
    <div class=\"container\">
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"";
        // line 11
        echo $this->env->getExtension('routing')->getPath("lddt_main_homepage");
        echo "\">Les dessins du téléphone</a>
        </div>
        <div class=\"collapse navbar-collapse\">
            <ul class=\"nav navbar-nav\">
                <li class=\"active\"><a href=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("lddt_main_homepage");
        echo "\">Voir les dessins</a></li>
                <li><a href=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("lddt_main_create");
        echo "\">Envoyer son dessin</a></li>
            </ul>

            <ul class=\"nav navbar-nav navbar-right\">
                ";
        // line 20
        if ($this->env->getExtension('security')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 21
            echo "  <li><span class=\"label label-success\">Bienvenue ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo " ! </span></li>
                    <li><a href=\"";
            // line 22
            echo $this->env->getExtension('routing')->getPath("fos_user_security_logout");
            echo "\" class=\"btn btn-danger\"> ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.logout", array(), "FOSUserBundle"), "html", null, true);
            echo "</a></li>
                    ";
        } else {
            // line 24
            echo "                    <li><a class=\"btn btn-small\" 
                           href=\"";
            // line 25
            echo $this->env->getExtension('routing')->getPath("fos_user_security_login");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.login", array(), "FOSUserBundle"), "html", null, true);
            echo "</a></li>
       <li> 
       <a href=\"";
            // line 27
            echo $this->env->getExtension('routing')->getPath("fos_user_registration_register");
            echo "\">Créer un compte</a></li>
                    ";
        }
        // line 28
        echo "  
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</div>
<!-- Fin Template menu principal -->";
    }

    public function getTemplateName()
    {
        return "LddtMainBundle:Main:menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 28,  73 => 27,  66 => 25,  63 => 24,  56 => 22,  51 => 21,  49 => 20,  42 => 16,  38 => 15,  31 => 11,  19 => 1,);
    }
}
