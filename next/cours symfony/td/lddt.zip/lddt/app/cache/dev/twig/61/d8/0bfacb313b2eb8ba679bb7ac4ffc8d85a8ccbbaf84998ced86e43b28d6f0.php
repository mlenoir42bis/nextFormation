<?php

/* LddtMainBundle:Main:form.html.twig */
class __TwigTemplate_61d80bfacb313b2eb8ba679bb7ac4ffc8d85a8ccbbaf84998ced86e43b28d6f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"well\">
    <form action=\"\" method=\"POST\" ";
        // line 2
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'enctype');
        echo " >
        ";
        // line 3
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <hr/>
        <input type=\"submit\" class=\"btn btn-success pull-right\" value=\"valider\"/>
    </form>
</div>
";
    }

    public function getTemplateName()
    {
        return "LddtMainBundle:Main:form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 3,  22 => 2,  19 => 1,);
    }
}
