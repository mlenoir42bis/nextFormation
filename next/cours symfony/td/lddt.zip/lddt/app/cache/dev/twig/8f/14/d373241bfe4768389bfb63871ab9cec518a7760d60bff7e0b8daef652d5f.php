<?php

/* LddtMainBundle:Main:index.html.twig */
class __TwigTemplate_8f14d373241bfe4768389bfb63871ab9cec518a7760d60bff7e0b8daef652d5f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("LddtMainBundle::main_n2.html.twig");

        $this->blocks = array(
            'n3' => array($this, 'block_n3'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "LddtMainBundle::main_n2.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_n3($context, array $blocks = array())
    {
        // line 4
        echo "     ";
        echo " 
      <div class=\"row\">
       ";
        // line 6
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "success"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 7
            echo "      <div class=\"alert alert-success\">
               ";
            // line 8
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "
        </div> 
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "        <!--  <div class=\"alert alert-error\">
               <p>Message d'erreur</p>
        </div> -->
        ";
        // line 14
        if (array_key_exists("cat", $context)) {
            // line 15
            echo "            <h1>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["cat"]) ? $context["cat"] : $this->getContext($context, "cat")), "name", array()), "html", null, true);
            echo "</h1>
        ";
        }
        // line 17
        echo "        ";
        if (array_key_exists("color", $context)) {
            // line 18
            echo "            <div class=\"row\">
                <h1>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["color"]) ? $context["color"] : $this->getContext($context, "color")), "name", array()), "html", null, true);
            echo "  <span class=\"colorBlock\" style=\"background:";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["color"]) ? $context["color"] : $this->getContext($context, "color")), "code", array()), "html", null, true);
            echo ";padding:20px;border-radius:70px\"></span>
                </h1>
           </div>
           <hr/>
        ";
        }
        // line 24
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["draws"]) ? $context["draws"] : $this->getContext($context, "draws")));
        foreach ($context['_seq'] as $context["_key"] => $context["draw"]) {
            // line 25
            echo "<!-- Boucle For -->
  <div class=\"col-lg-4\">
     <div class=\"thumbnail\">
      <img class=\"img-thumbnail\" src=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl($this->getAttribute($context["draw"], "getWebPath", array())), "html", null, true);
            echo "\" />         <div class=\"caption\">
             <p><strong>";
            // line 29
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute($context["draw"], "title", array())), "html", null, true);
            echo "</strong></p>
               <p><a 
 href=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("lddt_main_category", array("id" => $this->getAttribute($this->getAttribute($context["draw"], "category", array()), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["draw"], "category", array()), "name", array()), "html", null, true);
            echo "</a></p>
               <div class=\"col-lg-3 col-lg-offset-9\">
                    <p class=\"AuthorName\">
                     <a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("lddt_main_user", array("id" => $this->getAttribute($this->getAttribute($context["draw"], "user", array()), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["draw"], "user", array()), "username", array()), "html", null, true);
            echo " </a>
    <img width=\"60\" class=\"img-circle\" src=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl($this->getAttribute($this->getAttribute($context["draw"], "user", array()), "getWebPath", array())), "html", null, true);
            echo "\" /> 
                  </p>
               </div>
<a class=\"btn btn-small btn-info\" 
   href=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("lddt_main_show", array("id" => $this->getAttribute($context["draw"], "id", array()))), "html", null, true);
            echo "\">Voir dessin <i class=\"icon-eye-open\"></i></a>
         </div>
    </div>
  </div>
<!-- Fin Boucle For -->
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['draw'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "   </div><!-- Fin Template Niveau 3 -->
";
    }

    public function getTemplateName()
    {
        return "LddtMainBundle:Main:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  132 => 45,  120 => 39,  113 => 35,  107 => 34,  99 => 31,  94 => 29,  90 => 28,  85 => 25,  81 => 24,  71 => 19,  68 => 18,  65 => 17,  59 => 15,  57 => 14,  52 => 11,  43 => 8,  40 => 7,  36 => 6,  31 => 4,  28 => 3,);
    }
}
