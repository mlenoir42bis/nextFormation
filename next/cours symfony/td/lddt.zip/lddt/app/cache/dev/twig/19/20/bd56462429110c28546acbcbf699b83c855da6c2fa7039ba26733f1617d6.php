<?php

/* LddtMainBundle::main_n2.html.twig */
class __TwigTemplate_1920bd56462429110c28546acbcbf699b83c855da6c2fa7039ba26733f1617d6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::main_n1.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'n3' => array($this, 'block_n3'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::main_n1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"container margin-container-top\">
";
        // line 7
        echo "        ";
        $this->displayBlock('n3', $context, $blocks);
        // line 10
        echo "    </div>
";
    }

    // line 7
    public function block_n3($context, array $blocks = array())
    {
        // line 8
        echo "        ";
    }

    public function getTemplateName()
    {
        return "LddtMainBundle::main_n2.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 8,  43 => 7,  38 => 10,  35 => 7,  32 => 4,  29 => 3,);
    }
}
