<?php

/* LddtMainBundle:Main:create.html.twig */
class __TwigTemplate_80763594caeb6c24945e1c1bac9192244a61cdb4000d25610e890dc8a69800fc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("LddtMainBundle::main_n2.html.twig");

        $this->blocks = array(
            'n3' => array($this, 'block_n3'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "LddtMainBundle::main_n2.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_n3($context, array $blocks = array())
    {
        // line 4
        echo "     <!-- Template Niveau 3 -->
<div class=\"row\">
    <div class=\"well well-lg\" style=\"height:450px\">
        
    
    
            <div class=\"col-lg-3 col-lg-offset-1\">
                <h1>Vous dessinez au téléphone ? </h1>
<img width=\"290\" 
     src=\"";
        // line 13
        echo "bundles/lddtassets/images/red-phone.jpg";
        echo "\" />
            </div>

            <div class=\"col-lg-5 col-lg-offset-1\">
                <h3>Envoyez votre dessin !</h3>
               
 ";
        // line 19
        if ($this->env->getExtension('security')->isGranted("ROLE_USER")) {
            echo "  
  <!-- Template Formulaire -->
    ";
            // line 21
            $this->env->loadTemplate("LddtMainBundle:Main:form.html.twig")->display($context);
            echo "   
  <!-- Fin Template Formulaire -->
 ";
        } else {
            // line 24
            echo "  <!-- Si le visiteur n'est pas identifié -->
    <p>Merci de vous <a href=\"";
            // line 25
            echo $this->env->getExtension('routing')->getPath("fos_user_security_login");
            echo "\"> identifier</a> pour poster vos dessins !</p>
 ";
        }
        // line 26
        echo "  
            </div>
    </div>
</div><!-- Fin Template Niveau 3 -->
";
    }

    public function getTemplateName()
    {
        return "LddtMainBundle:Main:create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  70 => 26,  65 => 25,  62 => 24,  56 => 21,  51 => 19,  42 => 13,  31 => 4,  28 => 3,);
    }
}
