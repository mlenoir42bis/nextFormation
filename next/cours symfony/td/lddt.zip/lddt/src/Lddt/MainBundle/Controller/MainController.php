<?php
namespace Lddt\MainBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

use Lddt\MainBundle\Entity\Draw;
use Lddt\MainBundle\Entity\Color;
use Lddt\MainBundle\Entity\Comment;
use Lddt\MainBundle\Entity\DrawRepository;
use Lddt\MainBundle\Form\DrawType;
use Lddt\MainBundle\Form\CommentType;
use Lddt\MainBundle\Form\FormHandler;
use Lddt\UserBundle\Entity\User;

class MainController extends Controller
{
    public function indexAction()
    {
         // Récupération de l'entity Manager de Doctrine
        $em = $this->getDoctrine()->getManager(); 
//$draws = $em->getRepository('LddtMainBundle:Draw')->findAll();
$draws = $em->getRepository('LddtMainBundle:Draw')->getAllDraws();
 return $this->render('LddtMainBundle:Main:index.html.twig',array('draws'=>$draws));
    }
    
    public function createAction() {
        // Récupération de l'entity Manager de Doctrine
        $em = $this->getDoctrine()->getManager();
//        $draw = new Draw();
//        $draw->setTitle("rdv");
//        $draw->setDrawPath("rdv.jpg");
//        
//        $em->persist($draw);
//        $em->flush();
    $user = $this->get('security.context')->getToken()->getUser();    
    $draw = new Draw($user);
    $form = $this->createForm(new DrawType(),$draw);
$formHandler = new FormHandler($form,$this->get('request'),$em);
        if($formHandler->process()) {
            return $this->redirect(
             $this->generateUrl('lddt_main_show',array('id'=>$draw->getId()))
                              );
        }
 return 
      $this->render('LddtMainBundle:Main:create.html.twig',
         array('form'=>$form->createView()));
    }
    
    /**
     * @Template
     */
    public function editAction(Draw $draw) {
       $em= $this->getDoctrine()->getManager();
       $form = $this->createForm(new DrawType(),$draw);
       $formHandler = new FormHandler($form,$this->get('request'),$em);
       if($formHandler->process()) {
            return $this->redirect(
     $this->generateUrl('lddt_main_show',array('id'=>$draw->getId()))
        );
        }
       $vars = array('draw'=>$draw, 'form'=>$form->createView());
        return $vars;
    }
    
    
    /**
     * @Template("LddtMainBundle:Main:index.html.twig")
     */
    public function viewByCatAction($id) {
    $cat = $this->getDoctrine()
               ->getManager()
               ->getRepository('LddtMainBundle:Category')
               ->find($id);
     // Récupérer les dessins qui sont liés à cet objet catégorie
    $em =  $this->getDoctrine()->getManager();
    $draws = $em->getRepository('LddtMainBundle:Draw')
                ->getDrawsByCat($cat);
    $vars = array('draws'=>$draws,'cat'=>$cat);
    return $vars;
//    return $this->render('LddtMainBundle:Main:index.html.twig',array('draws'=>$draws,'cat'=>$cat));
    }
    
    /**
     * @Template
     */
    public function showAction(Draw $draw) {
        $em = $this->getDoctrine()->getManager();
        $comments = $draw->getComments();
        $user = $this->get('security.context')->getToken()->getUser();
        $comment = new Comment($draw,$user);
        $form = $this->createForm(new CommentType(),$comment);
        $formHandler = new FormHandler($form,$this->get('request'),$em);
        if($formHandler->process()) {
    return $this->redirect(
        $this->generateUrl("lddt_main_show",array('id'=>$draw->getId())));
      }
      if($user == $draw->getUser()) {
          $proprio = true;
      } else {
          $proprio = false;
      }
      
        $vars = array('draw'=>$draw,
                      'form'=>$form->createView(),
                      'comments'=>$comments,
                      'proprio'=>$proprio);
        return $vars;
    }
    
    /**
     * @Template("LddtMainBundle:Main:index.html.twig")
     */
    public function viewByColorAction(Color $color) {
        $em = $this->getDoctrine()->getManager();
        $draws = $em->getRepository('LddtMainBundle:Draw')
                    ->getDrawsByColor(array($color->getId()));
        
        $vars = array('draws'=>$draws,'color'=>$color);
        return $vars;
    }
    
    /**
     * @Template("LddtMainBundle:Main:index.html.twig")
     */
    public function viewByAuthorAction(User $user) {
        $em = $this->getDoctrine()->getManager(); 
         $draws = $em->getRepository('LddtMainBundle:Draw')
                    ->getDrawsByAuthor($user);
         $vars = array('draws'=>$draws,'author'=>$user);
         return $vars;
    }
    
    public function deleteAction(Draw $draw) {
        $em = $this->getDoctrine()->getManager(); 
        $em->remove($draw);
        $em->flush();
        $this->get('session')->getFlashBag()->add('success','le dessin a bien été supprimé');
        return $this->redirect($this->generateUrl('lddt_main_homepage'));
    }
    
    
}












