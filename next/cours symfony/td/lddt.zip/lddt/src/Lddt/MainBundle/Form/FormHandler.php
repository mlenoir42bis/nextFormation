<?php
namespace Lddt\MainBundle\Form;
use Symfony\Component\Form\Form;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\EntityManager;


/**
 * Description of FormHandler
 *
 * @author stagiaire
 */
class FormHandler {
    protected $form;
    protected $em;
    protected $request;
    
    public function __construct(Form $form,Request $request,EntityManager $em) {
        $this->form = $form;
        $this->request = $request;
        $this->em = $em;
    }
    
    public function process() {
        if($this->request->getMethod()=="POST") {
            $this->form->bind($this->request);
            if($this->form->isValid()) {
                $this->onSuccess($this->form->getData());
                return true;
            }
        }
        return false;
    }
    
    private function onSuccess($objet) {
        $this->em->persist($objet);
        $this->em->flush();
    }
}
