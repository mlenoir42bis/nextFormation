<?php

namespace Lddt\MainBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LddtMainBundle extends Bundle
{
}
