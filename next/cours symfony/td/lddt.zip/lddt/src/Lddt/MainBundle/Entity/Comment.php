<?php

namespace Lddt\MainBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Comment
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Lddt\MainBundle\Entity\CommentRepository")
 */
class Comment
{
    /**
     * @ORM\ManyToOne(targetEntity="Lddt\MainBundle\Entity\Draw",inversedBy="comments")
     * @ORM\JoinColumn(nullable=false,onDelete="CASCADE")
     */
    private $draw;
    
     /**
     * @ORM\ManyToOne(targetEntity="Lddt\UserBundle\Entity\User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id",onDelete="CASCADE")
     */
    private $user;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

  

    /**
     * @var string
     *
     * @ORM\Column(name="content", type="text")
     */
    private $content;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime")
     */
    private $createdAt;

    public function __construct($draw,$user) {
        $this->createdAt = new \DateTime();
        $this->draw = $draw;
        $this->user = $user;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    
    /**
     * Set content
     *
     * @param string $content
     * @return Comment
     */
    public function setContent($content)
    {
        $this->content = $content;

        return $this;
    }

    /**
     * Get content
     *
     * @return string 
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     * @return Comment
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime 
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set draw
     *
     * @param \Lddt\MainBundle\Entity\Draw $draw
     * @return Comment
     */
    public function setDraw(\Lddt\MainBundle\Entity\Draw $draw)
    {
        $this->draw = $draw;

        return $this;
    }

    /**
     * Get draw
     *
     * @return \Lddt\MainBundle\Entity\Draw 
     */
    public function getDraw()
    {
        return $this->draw;
    }

    /**
     * Set user
     *
     * @param \Lddt\UserBundle\Entity\User $user
     * @return Comment
     */
    public function setUser(\Lddt\UserBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \Lddt\UserBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }
}
