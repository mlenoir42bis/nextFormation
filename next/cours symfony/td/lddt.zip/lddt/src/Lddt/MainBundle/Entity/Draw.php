<?php

namespace Lddt\MainBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\HttpFoundation\File\UploadedFile;

/**
 * Draw
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Lddt\MainBundle\Entity\DrawRepository")
 * @ORM\HasLifecycleCallbacks
 */
class Draw
{
    
   /**
    * @ORM\OneToMany(targetEntity="Lddt\MainBundle\Entity\Comment", mappedBy="draw")
    */ 
    private $comments;
    
  /**
   * @ORM\ManyToMany(targetEntity="Lddt\MainBundle\Entity\Color",
   * cascade={"persist"})
   */
    private $colors;

   /**
    * Plusieurs Dessins dans une catégorie Many Draws To One Category
    * @ORM\ManyToOne(targetEntity="Lddt\MainBundle\Entity\Category")
    * @ORM\JoinColumn(name="cat_id", referencedColumnName="id",onDelete="CASCADE")
     */
    private $category;
    
    /**
     *
     * @ORM\ManyToOne(targetEntity="Lddt\UserBundle\Entity\User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id",onDelete="CASCADE")
     */
    private $user;
    
    
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="draw_path", type="string", length=255)
     */
    private $drawPath;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_online", type="boolean")
     */
    private $isOnline;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime")
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime")
     */
    private $updatedAt;

    /**
     * @Assert\File(
     *    maxSize= "1024k",
     *    maxSizeMessage = "Votre fichier doit être inférieur à 1Mo",
     *    mimeTypes = {"image/jpeg", "image/png", "image/gif"},
     *    mimeTypesMessage = "Merci d'uploader un jpg, png ou gif"
     *    )
     */
    private $drawFile;
    
    public function __construct($user) {
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
        $this->isOnline = true;
        $this->user = $user;
    }
    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Draw
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set drawPath
     *
     * @param string $drawPath
     * @return Draw
     */
    public function setDrawPath($drawPath)
    {
        $this->drawPath = $drawPath;

        return $this;
    }

    /**
     * Get drawPath
     *
     * @return string 
     */
    public function getDrawPath()
    {
        return $this->drawPath;
    }

    /**
     * Set isOnline
     *
     * @param boolean $isOnline
     * @return Draw
     */
    public function setIsOnline($isOnline)
    {
        $this->isOnline = $isOnline;

        return $this;
    }

    /**
     * Get isOnline
     *
     * @return boolean 
     */
    public function getIsOnline()
    {
        return $this->isOnline;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     * @return Draw
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime 
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     * @return Draw
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime 
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set category
     *
     * @param \Lddt\MainBundle\Entity\Category $category
     * @return Draw
     */
    public function setCategory(\Lddt\MainBundle\Entity\Category $category = null)
    {
        $this->category = $category;

        return $this;
    }

    /**
     * Get category
     *
     * @return \Lddt\MainBundle\Entity\Category 
     */
    public function getCategory()
    {
        return $this->category;
    }
    
    public function getDrawFile() {
        return $this->drawFile;
    }

    public function setDrawFile(UploadedFile $drawFile) {
        $this->drawFile = $drawFile;
        return $this;
    }
    
    // Retourner le chemin absolu d'un fichier (surtout utilisé dans un controller)
    public function getAbsolutePath() {
        return null === $this->drawPath ? null : 
                $this->getUploadRootDir()."/".$this->drawPath;
    }
    
    // Récupérer le chemin d'un fichié uploadé (surtout utilisé depuis un template Twig
    public function getWebPath() {
        return null === $this->drawPath ? null :
                $this->getUploadDir().'/'.$this->drawPath;
    }
    
  protected function getUploadRootDir() {
   return __DIR__.'/../../../../web/'.$this->getUploadDir();
  }
  
  protected function getUploadDir() {
        return "uploads/draws";
    }
    
  /**
   * @ORM\PrePersist()
   * @ORM\PreUpdate()
   */
    public function preUpload() {
        if(null !== $this->drawFile) {
            // Crypter le nom du fichier uploadé
  $this->drawPath = 
  sha1(uniqid(mt_rand(),true)).'.'.$this->drawFile->guessExtension();
        }
    }
    
    /**
     * @ORM\PostPersist()
     * @ORM\PostUpdate()
     */
    public function upload() {
        if(null === $this->drawFile) {
            return;
        }
        $this->drawFile->move($this->getUploadRootDir(),
                $this->drawPath);
        
    }
    
    /**
     * @ORM\PostRemove()
     */
    public function removeUpload() {
        if($file = $this->getAbsolutePath()) {
            unlink($file);
        }
    }

    /**
     * Add colors
     *
     * @param \Lddt\MainBundle\Entity\Color $colors
     * @return Draw
     */
    public function addColor(\Lddt\MainBundle\Entity\Color $colors)
    {
        $this->colors[] = $colors;

        return $this;
    }

    /**
     * Remove colors
     *
     * @param \Lddt\MainBundle\Entity\Color $colors
     */
    public function removeColor(\Lddt\MainBundle\Entity\Color $colors)
    {
        $this->colors->removeElement($colors);
    }

    /**
     * Get colors
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getColors()
    {
        return $this->colors;
    }

    /**
     * Add comments
     *
     * @param \Lddt\MainBundle\Entity\Comment $comments
     * @return Draw
     */
    public function addComment(\Lddt\MainBundle\Entity\Comment $comments)
    {
        $this->comments[] = $comments;

        return $this;
    }

    /**
     * Remove comments
     *
     * @param \Lddt\MainBundle\Entity\Comment $comments
     */
    public function removeComment(\Lddt\MainBundle\Entity\Comment $comments)
    {
        $this->comments->removeElement($comments);
    }

    /**
     * Get comments
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getComments()
    {
        return $this->comments;
    }

    /**
     * Set user
     *
     * @param \Lddt\UserBundle\Entity\User $user
     * @return Draw
     */
    public function setUser(\Lddt\UserBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \Lddt\UserBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }
}
