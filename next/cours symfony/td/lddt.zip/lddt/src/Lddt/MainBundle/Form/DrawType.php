<?php

namespace Lddt\MainBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class DrawType extends AbstractType {

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options) {
        $builder->add('title', 'text', array('label' => "Nom du dessin",
            'attr' => array('class' => 'form-control', 'placeholder' => '...'))
        );

        $builder->add('category', 'entity', array('label' => "choisissez votre catégorie",
                    'attr' => array('class' => 'form-control'),
                    'class' => 'Lddt\MainBundle\Entity\Category', 'property' => 'name'))
                ->add('colors', 'entity', array('label' => "Associez les couleurs à votre dessin", "class" => "Lddt\MainBundle\Entity\Color", "property" => "name",
                    "multiple" => true,
                    "expanded" => true));
        
 if ($builder->getData()->getId() == false) {
            $builder->add('drawFile', 'file', array('label' => "uploadez votre dessin"));
  }
        
        // Sinon champs file non obligatoire
//         $builder->add('drawFile', 'file', array('label' => "uploadez votre dessin","required"=>false));
    }

    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver) {
        $resolver->setDefaults(array(
            'data_class' => 'Lddt\MainBundle\Entity\Draw'
        ));
    }

    /**
     * @return string
     */
    public function getName() {
        return 'lddt_mainbundle_draw';
    }

}
