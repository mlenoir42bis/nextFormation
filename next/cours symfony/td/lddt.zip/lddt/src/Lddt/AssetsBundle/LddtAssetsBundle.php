<?php

namespace Lddt\AssetsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LddtAssetsBundle extends Bundle
{
}
